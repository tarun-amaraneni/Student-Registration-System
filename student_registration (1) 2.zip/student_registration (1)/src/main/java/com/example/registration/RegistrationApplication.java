package com.example.registration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class RegistrationApplication {
    public static void main(String[] args) {
        SpringApplication.run(RegistrationApplication.class, args);
    }
}

@Controller
class StudentController {

    private static final String FILE_PATH = "students.txt";

    @GetMapping("/")
    public String showForm() {
        return "index";
    }

    @PostMapping("/register")
    public String registerStudent(@RequestParam String name, @RequestParam String rollNumber, @RequestParam String email) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            writer.write(name + "," + rollNumber + "," + email);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "redirect:/students";
    }

    @GetMapping("/students")
    public String viewStudents(Model model) {
        List<String[]> studentList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                studentList.add(line.split(","));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        model.addAttribute("students", studentList);
        return "students";
    }

    @PostMapping("/delete")
    public String deleteStudent(@RequestParam String rollNumber) {
        List<String> remaining = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.contains("," + rollNumber + ",")) {
                    remaining.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String line : remaining) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "redirect:/students";
    }

    @GetMapping("/edit")
    public String editForm(@RequestParam String rollNumber, Model model) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(rollNumber)) {
                    model.addAttribute("name", parts[0]);
                    model.addAttribute("rollNumber", parts[1]);
                    model.addAttribute("email", parts[2]);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "edit";
    }

    @PostMapping("/update")
    public String updateStudent(@RequestParam String name, @RequestParam String rollNumber, @RequestParam String email) {
        List<String> updatedList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(rollNumber)) {
                    updatedList.add(name + "," + rollNumber + "," + email);
                } else {
                    updatedList.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String line : updatedList) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "redirect:/students";
    }
}